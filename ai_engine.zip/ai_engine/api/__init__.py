"""
API package initializer
"""
