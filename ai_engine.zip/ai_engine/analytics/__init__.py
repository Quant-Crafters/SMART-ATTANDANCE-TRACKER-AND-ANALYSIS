"""
Analytics package initializer
"""
