"""
Database package initializer
"""
