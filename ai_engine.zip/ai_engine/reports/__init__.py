"""
Reports package initializer
"""
