"""
Models package initializer
"""
