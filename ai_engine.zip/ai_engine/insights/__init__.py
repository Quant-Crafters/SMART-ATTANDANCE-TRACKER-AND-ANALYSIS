"""
Insights package initializer
"""
