"""
Tests package initializer
"""
